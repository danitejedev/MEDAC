document.getElementById('appointmentForm').addEventListener('submit', (event) => {
    event.preventDefault();

    //Aqui obtengo los valores
    const date = document.getElementById('date').value;
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const dni = document.getElementById('dni').value;
    const birthDate = document.getElementById('birthDate').value;
    const notes = document.getElementById('notes').value;

    //Creo un objeto
    const newAppointment = { date, firstName, lastName, dni, birthDate, notes };

    // Lo leo
    const existingAppointments = JSON.parse(localStorage.getItem('appointments') || '[]');

    //Agrego la cita
    existingAppointments.push(newAppointment);

    //Guardo la cita en LocalStorage
    localStorage.setItem('appointments', JSON.stringify(existingAppointments));

    alert('Cita creada con éxito.');
    event.target.reset();
});
