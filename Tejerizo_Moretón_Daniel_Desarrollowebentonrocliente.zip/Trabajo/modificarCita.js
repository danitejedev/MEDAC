document.addEventListener('DOMContentLoaded', () => {
    const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
    const tbody = document.querySelector('table tbody');

    //Creo las filas
    appointments.forEach((appointment, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${appointment.date}</td>
            <td>${appointment.firstName}</td>
            <td>${appointment.lastName}</td>
            <td>${appointment.dni}</td>
            <td>${appointment.birthDate}</td>
            <td>${appointment.notes || ''}</td>
            <td class="action-buttons">
                <button class="btn" onclick="editAppointment(${index})">Editar</button>
                <button class="btn" onclick="deleteAppointment(${index})">Eliminar</button>
            </td>
        `;
        tbody.appendChild(row);
    });
});

let editIndex = null;

function editAppointment(index) {
    const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
    const appointment = appointments[index];

    document.getElementById('editDate').value = appointment.date;
    document.getElementById('editFirstName').value = appointment.firstName;
    document.getElementById('editLastName').value = appointment.lastName;
    document.getElementById('editDni').value = appointment.dni;
    document.getElementById('editBirthDate').value = appointment.birthDate;
    document.getElementById('editNotes').value = appointment.notes || '';

    document.getElementById('editFormContainer').classList.remove('hidden');
    editIndex = index;
}

function deleteAppointment(index) {
    const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
    appointments.splice(index, 1);
    localStorage.setItem('appointments', JSON.stringify(appointments));
    location.reload();
}

document.getElementById('editForm').addEventListener('submit', (event) => {
    event.preventDefault();

    const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');

    appointments[editIndex] = {
        date: document.getElementById('editDate').value,
        firstName: document.getElementById('editFirstName').value,
        lastName: document.getElementById('editLastName').value,
        dni: document.getElementById('editDni').value,
        birthDate: document.getElementById('editBirthDate').value,
        notes: document.getElementById('editNotes').value
    };

    localStorage.setItem('appointments', JSON.stringify(appointments));
    document.getElementById('editFormContainer').classList.add('hidden');
    location.reload();
});

function cancelEdit() {
    document.getElementById('editFormContainer').classList.add('hidden');
    editIndex = null;
}
